package com.compassmod;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import org.lwjgl.glfw.GLFW;

public class CompassModClient implements ClientModInitializer {

    public static class_304 toggleCompassKey;

    @Override
    public void onInitializeClient() {
        class_304.class_11900 compassCategory = class_304.class_11900.method_74698(
            class_2960.method_60655("compassmod", "keys")
        );

        toggleCompassKey = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.compassmod.toggle",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_Z,
            compassCategory
        ));

        HudRenderCallback.EVENT.register((drawContext, deltaTracker) ->
            CompassHud.render(drawContext, deltaTracker.method_60637(true))
        );

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.field_1724 == null) return;

            long handle = GLFW.glfwGetCurrentContext();

            boolean ctrlHeld = GLFW.glfwGetKey(handle, GLFW.GLFW_KEY_LEFT_CONTROL) == GLFW.GLFW_PRESS
                            || GLFW.glfwGetKey(handle, GLFW.GLFW_KEY_RIGHT_CONTROL) == GLFW.GLFW_PRESS;
            boolean altHeld  = GLFW.glfwGetKey(handle, GLFW.GLFW_KEY_LEFT_ALT) == GLFW.GLFW_PRESS
                            || GLFW.glfwGetKey(handle, GLFW.GLFW_KEY_RIGHT_ALT) == GLFW.GLFW_PRESS;

            while (toggleCompassKey.method_1436()) {
                if (ctrlHeld && altHeld) {
                    CompassHud.cycleMode();
                    client.field_1724.method_7353(
                        net.minecraft.class_2561.method_43470(
                            "§6[Compass] §fMode: §e" + CompassHud.getModeName()
                        ), true
                    );
                }
            }
        });

        CompassCommand.register();
        CompassMod.LOGGER.info("CompassMod client initialized!");
    }
}
